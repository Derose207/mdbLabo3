﻿using MDB.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Runtime.InteropServices;
using System.Web.Helpers;
using System.Web.Mvc;

namespace MDB.Controllers
{
    public class AccountsController : Controller
    {
        private readonly AppDBEntities DB = new AppDBEntities();

        [HttpPost]
        public JsonResult EmailExist(string email)
        {
            return Json(DB.EmailExist(email));
        }

        [HttpPost]
        public JsonResult EmailAvailable(string email, int id)
        {
            return Json(DB.EmailAvailable(email, id));
        }

        #region Login and Logout
        public ActionResult Login(string message)
        {
            LoginCredential credential = new LoginCredential();
            ViewBag.Message = message;

            return View(credential);
        }
        [HttpPost]
        [ValidateAntiForgeryToken()]
        public ActionResult Login(LoginCredential loginCredential)
        {
            if (ModelState.IsValid)
            {
                if (DB.EmailBlocked(loginCredential.Email))
                {
                    ModelState.AddModelError("Email", "Ce compte est bloqué.");
                    return View(loginCredential);
                }
                if (!DB.EmailVerified(loginCredential.Email))
                {
                    ModelState.AddModelError("Email", "Ce courriel n'est pas vérifié.");
                    return View(loginCredential);
                }
                User user = DB.GetUser(loginCredential);
                if (user == null)
                {
                    ModelState.AddModelError("Password", "Mot de passe incorrecte.");
                    return View(loginCredential);
                }
                if (OnlineUsers.IsOnLine(user.Id))
                {
                    ModelState.AddModelError("Email", "Cet usager est déjà connecté.");
                    return View(loginCredential);
                }
                OnlineUsers.AddSessionUser(user.Id);
                Session["currentLoginId"] = DB.AddLogin(user.Id).Id;
                return RedirectToAction("Index", "Movies");
            }
            return View(loginCredential);
        }
        public ActionResult Logout()
        {
            if (Session["currentLoginId"] != null)
                DB.UpdateLogout((int)Session["currentLoginId"]);
            OnlineUsers.RemoveSessionUser();
            return RedirectToAction("Login");
        }
        #endregion
        public ActionResult Subscribe()
        {
            ViewBag.Genders = SelectListUtilities<Gender>.Convert(DB.Genders.ToList());
            return View(new User());
        }
        [HttpPost]
        public ActionResult Subscribe(User user)
        {
            if (ModelState.IsValid)
            {
                // Evoyer Email 
                // SMTP.SendEmail(user.FirstName, user.Email, user.FirstName, user.LastName);

                DB.AddUser(user);
                SendEmailVerification(user, user.Email);

                //  string statusMessage = "Message envoyé a  avec succès";



                return RedirectToAction("SubscribeDone");
            }

            return View(user);
        }
        public ActionResult SubscribeDone()
        {
            // User user = User.Find
            //ViewBag.Genders = SelectListUtilities<Gender>.Convert(DB.Genders.ToList());
            return View(new User());
        }
        [HttpPost]
        public ActionResult SubscribeDone(User user)
        {
            if (ModelState.IsValid)
            {
                // Evoyer Email 
                // SMTP.SendEmail(user.FirstName, user.Email, user.FirstName, user.LastName);

                // DB.AddUser(user);
                //SendEmailVerification(user, user.Email);


                return RedirectToAction("Login");
            }

            return View(user);
        }

        public ActionResult VerifyDone()
        {
            //ViewBag.Genders = SelectListUtilities<Gender>.Convert(DB.Genders.ToList());
            return View(new User());
        }
        [HttpPost]
        public ActionResult VerifyDone(User user)
        {
            if (ModelState.IsValid)
            {
                // Evoyer Email 
                // SMTP.SendEmail(user.FirstName, user.Email, user.FirstName, user.LastName);

                // DB.AddUser(user);
                //SendEmailVerification(user, user.Email);


                return RedirectToAction("SubscribeDone");
            }

            return View(user);
        }
        public void SendEmailVerification(User user, string newEmail)
        {
            if (user.Id != 0)
            {
                UnverifiedEmail unverifiedEmail = DB.Add_UnverifiedEmail(user.Id, newEmail);
                if (unverifiedEmail != null)
                {
                    string verificationUrl = Url.Action("VerifyUser", "Accounts", null, Request.Url.Scheme);
                    String Link = @"<br/><a href='" + verificationUrl + "?userid=" + user.Id + "&code=" + unverifiedEmail.VerificationCode + @"' > Confirmez votre inscription...</a>";

                    String suffixe = "";
                    if (user.GenderId == 2)
                    {
                        suffixe = "e";
                    }
                    string Subject = "MDB - Vérification d'inscription...";

                    string Body = "Bonjour " + user.GetFullName(true) + @",<br/><br/>";
                    Body += @"Merci de vous être inscrit" + suffixe + " au site MDB. <br/>";
                    Body += @"Pour utiliser votre compte vous devez confirmer votre inscription en cliquant sur le lien suivant : <br/>";
                    Body += Link;
                    Body += @"<br/><br/>Ce courriel a été généré automatiquement, veuillez ne pas y répondre.";
                    Body += @"<br/><br/>Si vous éprouvez des difficultés ou s'il s'agit d'une erreur, veuillez le signaler à <a href='mailto:"
                         + SMTP.OwnerEmail + "'>" + SMTP.OwnerName + "</a> (Webmestre du site MDB)";

                    SMTP.SendEmail(user.GetFullName(), unverifiedEmail.Email, Subject, Body);
                }
            }
        }
        public ActionResult VerifyUser()
        {

            int userId = 0;
            int code = 0;

            if (int.TryParse(Request.QueryString["userid"], out userId) && int.TryParse(Request.QueryString["code"], out code))
            {

                
                if( AppDBDAL.VerifyUser(DB, userId, code) != true )
                {
                    return RedirectToAction("verifyError");
                }

            }
            else
            {
                return RedirectToAction("verifyError");
                // Les valeurs des paramètres "userid" et "code" ne sont pas des entiers valides
                // Gérer l'erreur ou rediriger l'utilisateur vers une page d'erreur appropriée
                // ...
            }
            return View();

           

        }

        [HttpPost]
        public ActionResult VerifyUser(User user)
        {
            if (ModelState.IsValid)
            {




                return RedirectToAction("VerifyDone");
            }

            return RedirectToAction("verifyError");
        }
        [OnlineUsers.UserAccess]
        public ActionResult Profil()
        {
            ViewBag.Genders = SelectListUtilities<Gender>.Convert(DB.Genders.ToList());
            User userToEdit = OnlineUsers.GetSessionUser();

            if (userToEdit != null)
            {
                Session["currentUserPassword"] = userToEdit.Password;
                Session["UnchangedPasswordCode"] = Guid.NewGuid().ToString().Substring(0, 12);
                userToEdit.Password = userToEdit.ConfirmPassword = (string)Session["UnchangedPasswordCode"];
                return View(userToEdit);
            }
            return null;
        }
        [HttpPost]
        public ActionResult Profil(User user)
        {
            
            if (ModelState.IsValid)
            {
                User currentUserBeforeEdit = OnlineUsers.GetSessionUser();
                
                if (user.Password == (string)Session["UnchangedPasswordCode"])
                {
                    user.Password = user.ConfirmPassword = (string)Session["currentUserPassword"];
                }
                if (currentUserBeforeEdit.Email == user.Email)
                {
                    DB.UpdateUser(user);
                    return RedirectToAction("Index", "Movies");
                }
                else
                {
                    user.Email = user.ConfirmEmail = currentUserBeforeEdit.Email;
                    DB.UpdateUser(user);
                    SendEmailVerificationChangeMail(user, user.Email);
                    return RedirectToAction("ChangeEmailDone");
                }
            }

            return RedirectToAction("Index", "Movies");
        }

        public void SendEmailVerificationChangeMail(User user, string newEmail)
        {
            if (user.Id != 0)
            {
                UnverifiedEmail unverifiedEmail = DB.Add_UnverifiedEmail(user.Id, newEmail);
                if (unverifiedEmail != null)
                {
                    string verificationUrl = Url.Action("ChangeEmail", "Accounts", null, Request.Url.Scheme);
                    String Link = @"<br/><a href='" + verificationUrl + "?userid=" + user.Id + "&code=" + unverifiedEmail.VerificationCode + "&user=" + user + @"' > Changement de couriel ...</a>";

                    String suffixe = "";
                    if (user.GenderId == 2)
                    {
                        suffixe = "e";
                    }
                    string Subject = "MDB - Changement de mot de passe...";

                    string Body = "Bonjour " + user.FirstName + @",<br/><br/>";
                    Body += @"Merci de vous être inscrit" + suffixe + " au site MDB. <br/>";
                    Body += @"Pour changer votre couriel vous devez confirmer votre changement en cliquant sur le lien suivant : <br/>";
                    Body += Link;
                    Body += @"<br/><br/>Ce courriel a été généré automatiquement, veuillez ne pas y répondre.";
                    Body += @"<br/><br/>Si vous éprouvez des difficultés ou s'il s'agit d'une erreur, veuillez le signaler à <a href='mailto:"
                         + SMTP.OwnerEmail + "'>" + SMTP.OwnerName + "</a> (Webmestre du site MDB)";

                    SMTP.SendEmail(user.GetFullName(), unverifiedEmail.Email, Subject, Body);
                }
            }
        }
        public ActionResult ChangeEmail()
        {

            int userId = 0;
            int code = 0;
            

            if (int.TryParse(Request.QueryString["userid"], out userId) && int.TryParse(Request.QueryString["code"], out code))
            {
                
                AppDBDAL.VerifyUser(DB, userId, code);
              


            }
            else
            {
                
            }

            return View();

        }
        [HttpPost]
        public ActionResult ChangeEmail(User user)
        {
            if (ModelState.IsValid)
            {
               


                OnlineUsers.RemoveSessionUser();
                return RedirectToAction("VerifyDone");
            }

            return RedirectToAction("VerifyDone");
        }
        public ActionResult ChangeEmailDone()
        {
            OnlineUsers.RemoveSessionUser();
            return View();
        }
        [HttpPost]
        public ActionResult ChangeEmailDone(User user)
        {
            if (ModelState.IsValid)
            {
                // Evoyer Email 
                // SMTP.SendEmail(user.FirstName, user.Email, user.FirstName, user.LastName);

                // DB.AddUser(user);
                //SendEmailVerification(user, user.Email);

                OnlineUsers.RemoveSessionUser();
                return RedirectToAction("Login");
            }

            return View(user);
        }
        public ActionResult ResetPasswordCommand()
        {
            // User user = User.Find
            //ViewBag.Genders = SelectListUtilities<Gender>.Convert(DB.Genders.ToList());
            
            return View();
        }
        [HttpPost]
        public ActionResult ResetPasswordCommand(User user)
        {
           
               
                SendEmailVerificationChangePassword(user.Email);

                return RedirectToAction("ResetPasswordmail");
            
        }
        public ActionResult ResetPasswordmail()
        {
            // User user = User.Find
            //ViewBag.Genders = SelectListUtilities<Gender>.Convert(DB.Genders.ToList());
            return View();
        }
        [HttpPost]
        public ActionResult ResetPasswordmail(string couriel)
        {
            if (ModelState.IsValid)
            {
                


                return RedirectToAction("ResetPasswordmail");
            }
            return View();

        }

        public void SendEmailVerificationChangePassword(string couriel)
        {
            
                // UnverifiedEmail unverifiedEmail = DB.Add_UnverifiedEmail(user.Id, newEmail);
                ResetPasswordCommand passwordCommand = DB.AddResetPasswordCommand(couriel);
                User user = DB.Users.Where(u => u.Email == couriel).FirstOrDefault();
                if (passwordCommand != null)
                { 
                   // ResetPasswordCommand resetPassword = 
                    string verificationUrl = Url.Action("ChangePassword", "Accounts", null, Request.Url.Scheme);
                    String Link = @"<br/><a href='" + verificationUrl + "?userid=" + passwordCommand.Id + "&code=" + passwordCommand.VerificationCode + "&user=" + user + @"' > Changement de mot de Passe ...</a>";

                
                    string Subject = "MDB - Changement de mot de passe...";

                    string Body = "Bonjour " + user.FirstName + @",<br/><br/>";
                   
                    Body += @"Vous avez demandé de réinitialiser votre mot de passe. <br/>";
                    Body += @"Procedez en cliquant sur le lien suivant: <br/>";
                    Body += Link;
                    Body += @"<br/><br/>Ce courriel a été généré automatiquement, veuillez ne pas y répondre.";
                    Body += @"<br/><br/>Si vous éprouvez des difficultés ou s'il s'agit d'une erreur, veuillez le signaler à <a href='mailto:"
                         + SMTP.OwnerEmail + "'>" + SMTP.OwnerName + "</a> (Webmestre du site MDB)";

                    SMTP.SendEmail(user.GetFullName(), couriel, Subject, Body);
                }
            
        }
        public ActionResult ChangePassword()
        {

            int userId = 0;
            int code = 0;


            if (int.TryParse(Request.QueryString["userid"], out userId) && int.TryParse(Request.QueryString["code"], out code) )
            {

                // AppDBDAL.VerifyUser(DB, userId, code);
                Session["userid"] = userId;

                DB.FindResetPasswordCommand( userId, code);

            }
            else
            {

            }

            return View();

        }
        [HttpPost]
        public ActionResult ChangePassword(User user)
        {
            int userid = (int)Session["userid"];
            if (ModelState.IsValid)
            {

                DB.ResetPassword(userid, user.Password);

              
                return RedirectToAction("ReinitialisationMotPDone");
            }

            return RedirectToAction("ReinitialisationMotPDone");
        }
        public ActionResult ReinitialisationMotPDone()
        {

            return View();

        }
        public ActionResult verifyError()
        {
            return View();
        }




        /*    [OnlineUsers.UserAccess]
            public ActionResult Profil()
            {
                ViewBag.Genders = SelectListUtilities<Gender>.Convert(DB.Genders.ToList());
                User userToEdit = OnlineUsers.GetSessionUser();

                if (userToEdit != null)
                {
                    Session["currentUserPassword"] = userToEdit.Password;
                    Session["UnchangedPasswordCode"] = Guid.NewGuid().ToString().Substring(0, 12);
                    userToEdit.Password = userToEdit.ConfirmPassword = (string)Session["UnchangedPasswordCode"];
                    return View(userToEdit);
                }
                return null;
            }
            [HttpPost]
            public ActionResult Profil(User user)
            {
                User userToEdit = OnlineUsers.GetSessionUser();
                if (ModelState.IsValid)
                {
                    DB.UpdateUser(userToEdit);
                }

                return View();
            }

            */

    }
}